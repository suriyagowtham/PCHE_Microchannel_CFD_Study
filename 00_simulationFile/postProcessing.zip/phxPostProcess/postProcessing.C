/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     | Version:  v2512
    \\  /    A nd           | Website:  www.openfoam.com
     \\/     M anipulation  |
-------------------------------------------------------------------------------
Description
    Custom post-processing utility for PCHE strip channel simulation.
    PCHE strip channel post-processing utility

Usage
    postProcessing  (run from case root directory)
\*---------------------------------------------------------------------------*/

#include "fvCFD.H"
#include "surfaceFields.H"

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

scalar patchAreaAverage
(
    const volScalarField& field,
    const label           patchID,
    const word&           patchName
)
{
    const fvPatch&    patch = field.mesh().boundary()[patchID];
    const scalarField pf    = field.boundaryField()[patchID];
    const scalarField magSf = patch.magSf();
    scalar sumVal  = gSum(pf * magSf);
    scalar sumArea = gSum(magSf);
    Info << "      Source patch : " << patchName        << nl
         << "      Patch faces  : " << patch.size()     << nl
         << "      Patch area   : " << sumArea << " m2" << nl;
    return (sumArea > SMALL) ? sumVal / sumArea : 0.0;
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

int main(int argc, char *argv[])
{
    timeSelector::addOptions(false, false);
    #include "setRootCase.H"
    #include "createTime.H"

    instantList timeDirs = timeSelector::selectIfPresent(runTime, args);
    runTime.setTime(timeDirs.last(), timeDirs.size() - 1);

    // ══════════════════════════════════════════════════════════════════════════
    // HARDCODED GEOMETRIC PARAMETERS -- MUST MATCH YOUR CASE
    // These values come from the strip channel geometry -- Paper Table 1
    // They are NOT available in any OpenFOAM case file (mesh, fields, dicts)
    // They represent the FULL STRIP geometry -- not just the channel interior
    //
    // IF YOU CHANGE THE GEOMETRY -- UPDATE THESE TWO VALUES:
    //
    const scalar W   = 3.6e-3;   // [m] Strip width        -- strip channel geometry Table 1
    const scalar tp2 = 3.2e-3;   // [m] 2x plate thickness -- strip channel geometry Table 1
    //
    // WHY HARDCODED:
    //   W   -- hot_inlet patch spans only the semicircular channel (d=2mm)
    //          NOT the full strip width (W=3.6mm)
    //          Mesh bounding box gives channel diameter, not strip width
    //   tp2 -- solid mesh bounding box includes channel geometry
    //          Cannot reliably extract plate-only thickness from mesh
    //          Must use paper-defined geometry value
    //
    // ══════════════════════════════════════════════════════════════════════════

    Info << nl
         << "=====================================================" << nl
         << "  PCHE Strip Channel -- Post-Processing"               << nl
         << "  Time = " << runTime.timeName()                       << nl
         << "=====================================================" << nl
         << endl;

    // ── CREATE ALL THREE MESHES ───────────────────────────────────────────────
    fvMesh meshHot
    (
        IOobject("hot_fluid", runTime.timeName(),
                 runTime, IOobject::MUST_READ)
    );
    fvMesh meshCold
    (
        IOobject("cold_fluid", runTime.timeName(),
                 runTime, IOobject::MUST_READ)
    );
    fvMesh meshSolid
    (
        IOobject("solid_plate", runTime.timeName(),
                 runTime, IOobject::MUST_READ)
    );

    // ── READ Cp FROM constant/hot_fluid/thermophysicalProperties ─────────────
    IOdictionary hotThermoDict
    (
        IOobject
        (
            "thermophysicalProperties",
            runTime.constant(),
            meshHot,
            IOobject::MUST_READ,
            IOobject::NO_WRITE
        )
    );

    scalar Cp = hotThermoDict.subDict("mixture")
                             .subDict("thermodynamics")
                             .get<scalar>("Cp");

    scalar mu_fluid = hotThermoDict.subDict("mixture")
                                   .subDict("transport")
                                   .get<scalar>("mu");

    scalar Pr_fluid = hotThermoDict.subDict("mixture")
                                   .subDict("transport")
                                   .get<scalar>("Pr");

    // kappa_fluid = mu x Cp / Pr   (Fourier's law from transport properties)
    scalar kappa_fluid = mu_fluid * Cp / Pr_fluid;

    Info << "  [thermophysicalProperties -- hot_fluid]"                   << nl
         << "    Cp           = " << Cp          << " J/kgK"             << nl
         << "    mu           = " << mu_fluid     << " Pa.s"             << nl
         << "    Pr           = " << Pr_fluid     << " [-]"              << nl
         << "    kappa_fluid  = mu x Cp / Pr"                            << nl
         << "                 = " << kappa_fluid  << " W/mK"             << nl << nl;

    // ── READ kappa_solid FROM constant/solid_plate/thermophysicalProperties ──
    IOdictionary solidThermoDict
    (
        IOobject
        (
            "thermophysicalProperties",
            runTime.constant(),
            meshSolid,
            IOobject::MUST_READ,
            IOobject::NO_WRITE
        )
    );

    scalar kappa_solid = solidThermoDict.subDict("mixture")
                                        .subDict("transport")
                                        .get<scalar>("kappa");

    Info << "  [thermophysicalProperties -- solid_plate]"                 << nl
         << "    kappa_solid  = " << kappa_solid << " W/mK"              << nl << nl;

    // ── READ ALL FIELDS ───────────────────────────────────────────────────────
    volScalarField p_rgh_hot
    (
        IOobject("p_rgh", runTime.timeName(), meshHot,
                 IOobject::MUST_READ, IOobject::NO_WRITE), meshHot
    );
    volScalarField T_hot
    (
        IOobject("T", runTime.timeName(), meshHot,
                 IOobject::MUST_READ, IOobject::NO_WRITE), meshHot
    );
    volScalarField p_rgh_cold
    (
        IOobject("p_rgh", runTime.timeName(), meshCold,
                 IOobject::MUST_READ, IOobject::NO_WRITE), meshCold
    );
    volScalarField T_cold
    (
        IOobject("T", runTime.timeName(), meshCold,
                 IOobject::MUST_READ, IOobject::NO_WRITE), meshCold
    );
    volScalarField T_solid
    (
        IOobject("T", runTime.timeName(), meshSolid,
                 IOobject::MUST_READ, IOobject::NO_WRITE), meshSolid
    );
    surfaceScalarField phi_hot
    (
        IOobject("phi", runTime.timeName(), meshHot,
                 IOobject::MUST_READ, IOobject::NO_WRITE), meshHot
    );
    surfaceScalarField phi_cold
    (
        IOobject("phi", runTime.timeName(), meshCold,
                 IOobject::MUST_READ, IOobject::NO_WRITE), meshCold
    );

    // ── GET ALL PATCH IDs ─────────────────────────────────────────────────────
    label hotInletID    = meshHot.boundaryMesh().findPatchID("hot_inlet");
    label hotOutletID   = meshHot.boundaryMesh().findPatchID("hot_outlet");
    label coldInletID   = meshCold.boundaryMesh().findPatchID("cold_inlet");
    label coldOutletID  = meshCold.boundaryMesh().findPatchID("cold_outlet");
    label hotToSolidID  = meshHot.boundaryMesh().findPatchID("hot_fluid_to_solid_plate");
    label coldToSolidID = meshCold.boundaryMesh().findPatchID("cold_fluid_to_solid_plate");
    label solidToHotID  = meshSolid.boundaryMesh().findPatchID("solid_plate_to_hot_fluid");
    label solidToColdID = meshSolid.boundaryMesh().findPatchID("solid_plate_to_cold_fluid");

    if (hotInletID < 0 || hotOutletID < 0)
        FatalErrorInFunction
            << "Cannot find hot_inlet or hot_outlet in hot_fluid"
            << abort(FatalError);
    if (coldInletID < 0 || coldOutletID < 0)
        FatalErrorInFunction
            << "Cannot find cold_inlet or cold_outlet in cold_fluid"
            << abort(FatalError);

    // ═════════════════════════════════════════════════════════════════════════
    // EXTRACT ALL GEOMETRY AND OPERATING CONDITIONS FROM MESH AND FIELDS
    // Nothing below is hardcoded -- all read automatically
    // ═════════════════════════════════════════════════════════════════════════

    // ── [1] Channel length from mesh ─────────────────────────────────────────
    const vectorField& hotInletCf  = meshHot.boundary()[hotInletID].Cf();
    const vectorField& hotOutletCf = meshHot.boundary()[hotOutletID].Cf();
    scalar Z_inlet       = gAverage(hotInletCf).z();
    scalar Z_outlet      = gAverage(hotOutletCf).z();
    scalar channelLength = mag(Z_outlet - Z_inlet);   // replaces hardcoded L

    Info << "  [A] Channel length -- from mesh patch face centres:"         << nl
         << "      hot_inlet  avg Z = " << Z_inlet  << " m"                << nl
         << "      hot_outlet avg Z = " << Z_outlet << " m"                << nl
         << "      channelLength    = " << channelLength << " m"           << nl
         << "                       = " << channelLength*1000 << " mm"     << nl << nl;

    // ── [2] Strip width W -- hardcoded (see line 58) ─────────────────────────
    // W cannot be reliably extracted from hot_inlet bounding box
    // hot_inlet spans only the semicircular channel (d=2mm) not full strip (W=3.6mm)
    Info << "  [B] Strip width W -- hardcoded value used:"                  << nl
         << "      W = " << W*1000 << " mm"                                << nl
         << "      See pressureDrop.C line 58 to change"                   << nl << nl;

    // ── [3] Inlet temperature T_h_in -- from hot_inlet fixedValue BC ─────────
    // Read the uniform value from the T field boundary condition
    scalar T_h_in = 0.0;
    const fvPatchScalarField& T_hot_inlet_BC =
        T_hot.boundaryField()[hotInletID];
    // For fixedValue BC the patch values equal the BC value
    T_h_in = gAverage(T_hot_inlet_BC);

    Info << "  [C] T_h_in -- from hot_inlet T boundary field:"              << nl
         << "      T_h_in = " << T_h_in << " K"                            << nl << nl;

    // ── [4] Inlet temperature T_c_in -- from cold_inlet fixedValue BC ────────
    scalar T_c_in = 0.0;
    const fvPatchScalarField& T_cold_inlet_BC =
        T_cold.boundaryField()[coldInletID];
    T_c_in = gAverage(T_cold_inlet_BC);

    Info << "  [D] T_c_in -- from cold_inlet T boundary field:"             << nl
         << "      T_c_in = " << T_c_in << " K"                            << nl << nl;

    // ── [5] Strip mass flow rate -- from phi at hot_inlet ────────────────────
    // phi is the mass flux [kg/s] -- sum over inlet patch = total mass flow
    scalar phi_hot_inlet_sum = gSum(phi_hot.boundaryField()[hotInletID]);
    scalar m_strip = mag(phi_hot_inlet_sum);   // replaces hardcoded m_strip

    Info << "  [E] m_strip -- from phi field at hot_inlet:"                 << nl
         << "      sum(phi at hot_inlet) = " << phi_hot_inlet_sum << " kg/s" << nl
         << "      m_strip (mag)         = " << m_strip << " kg/s"         << nl
         << "                            = " << m_strip*3600*120 << " kg/h (full PCHE)" << nl << nl;

    Info << "  Summary of extracted values:"                                      << nl
         << "    channelLength = " << channelLength*1000 << " mm  [from mesh -- patch face centres]"         << nl
         << "    W             = " << W*1000    << " mm  [HARDCODED -- pressureDrop.C line 58]"              << nl
         << "    tp2           = " << tp2*1000  << " mm  [HARDCODED -- pressureDrop.C line 59]"              << nl
         << "    T_h_in        = " << T_h_in   << " K   [from " << runTime.timeName() << "/hot_fluid/T BC]"  << nl
         << "    T_c_in        = " << T_c_in   << " K   [from " << runTime.timeName() << "/cold_fluid/T BC]" << nl
         << "    m_strip       = " << m_strip  << " kg/s [from " << runTime.timeName() << "/hot_fluid/phi]"  << nl
         << "    Cp            = " << Cp       << " J/kgK [from constant/hot_fluid/thermophysicalProperties]"     << nl
         << "    kappa_fluid   = " << kappa_fluid << " W/mK [computed: mu x Cp / Pr from thermophysicalProperties]" << nl
         << "    kappa_solid   = " << kappa_solid << " W/mK [from constant/solid_plate/thermophysicalProperties]"   << nl
         << endl;

    // ── HARDCODED VALUES DISCLAIMER ──────────────────────────────────────────
    Info << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << nl
         << "  HARDCODED GEOMETRIC PARAMETERS -- USER ACTION REQUIRED" << nl
         << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << nl
         << nl
         << "  The following values are hardcoded in pressureDrop.C" << nl
         << "  They are NOT read from any OpenFOAM case file"        << nl
         << "  Verify these match your simulation geometry:"         << nl
         << nl
         << "  W   = " << W*1000   << " mm  (strip width)"          << nl
         << "        Source : strip channel geometry specification"          << nl
         << "        File   : pressureDrop.C  line 58"               << nl
         << "        Code   : const scalar W = 3.6e-3;"              << nl
         << nl
         << "  tp2 = " << tp2*1000 << " mm  (2 x plate thickness)"  << nl
         << "        Source : strip channel geometry specification"          << nl
         << "        File   : pressureDrop.C  line 59"               << nl
         << "        Code   : const scalar tp2 = 3.2e-3;"            << nl
         << nl
         << "  Used for: Q_vol = Q_hot / (W x tp2 x L) / 1e6"       << nl
         << "  To change: edit pressureDrop.C lines 58-59 and recompile" << nl
         << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << nl
         << endl;

    // ── HOT FLUID ────────────────────────────────────────────────────────────
    Info << "-----------------------------------------------------" << nl
         << "  HOT FLUID REGION"                                     << nl
         << "-----------------------------------------------------" << nl << endl;

    Info << "  [1] p_rgh at hot_inlet:" << nl;
    scalar P_hot_in  = patchAreaAverage(p_rgh_hot, hotInletID,  "hot_inlet");
    Info << "      P_hot_inlet  = " << P_hot_in << " Pa" << nl << nl;

    Info << "  [2] p_rgh at hot_outlet:" << nl;
    scalar P_hot_out = patchAreaAverage(p_rgh_hot, hotOutletID, "hot_outlet");
    Info << "      P_hot_outlet = " << P_hot_out << " Pa" << nl << nl;

    scalar dP_hot   = P_hot_in - P_hot_out;
    scalar dPdL_hot = dP_hot / channelLength;
    Info << "  [3] Hot channel pressure drop:"                     << nl
         << "      dP_hot = P_hot_inlet - P_hot_outlet"           << nl
         << "             = " << dP_hot << " Pa"                  << nl
         << "             = " << dP_hot/1000.0 << " kPa"         << nl
         << "      Pressure gradient (dP/L):"                     << nl
         << "             = " << dPdL_hot << " Pa/m"              << nl
         << "             = " << dPdL_hot/1000.0 << " kPa/m"     << nl << nl;

    Info << "  [4] T at hot_outlet:" << nl;
    scalar T_hot_out = patchAreaAverage(T_hot, hotOutletID, "hot_outlet");
    Info << "      T_hot_outlet = " << T_hot_out << " K" << nl << endl;

    // ── COLD FLUID ───────────────────────────────────────────────────────────
    Info << "-----------------------------------------------------" << nl
         << "  COLD FLUID REGION"                                    << nl
         << "-----------------------------------------------------" << nl << endl;

    Info << "  [1] p_rgh at cold_inlet:" << nl;
    scalar P_cold_in  = patchAreaAverage(p_rgh_cold, coldInletID,  "cold_inlet");
    Info << "      P_cold_inlet  = " << P_cold_in << " Pa" << nl << nl;

    Info << "  [2] p_rgh at cold_outlet:" << nl;
    scalar P_cold_out = patchAreaAverage(p_rgh_cold, coldOutletID, "cold_outlet");
    Info << "      P_cold_outlet = " << P_cold_out << " Pa" << nl << nl;

    scalar dP_cold   = P_cold_in - P_cold_out;
    scalar dPdL_cold = dP_cold / channelLength;
    Info << "  [3] Cold channel pressure drop:"                      << nl
         << "      dP_cold = P_cold_inlet - P_cold_outlet"          << nl
         << "              = " << dP_cold << " Pa"                  << nl
         << "              = " << dP_cold/1000.0 << " kPa"         << nl
         << "      Pressure gradient (dP/L):"                       << nl
         << "              = " << dPdL_cold << " Pa/m"              << nl
         << "              = " << dPdL_cold/1000.0 << " kPa/m"     << nl << nl;

    Info << "  [4] T at cold_outlet:" << nl;
    scalar T_cold_out = patchAreaAverage(T_cold, coldOutletID, "cold_outlet");
    Info << "      T_cold_outlet = " << T_cold_out << " K" << nl << endl;

    // ── DERIVED QUANTITIES ────────────────────────────────────────────────────
    Info << "-----------------------------------------------------" << nl
         << "  DERIVED QUANTITIES"                                   << nl
         << "-----------------------------------------------------" << nl << endl;

    scalar Q_hot  = m_strip * Cp * (T_h_in - T_hot_out);
    scalar Q_cold = m_strip * Cp * (T_cold_out - T_c_in);

    Info << "  Q_hot [W]"                                                  << nl
         << "    Formula : Q_hot = m_strip x Cp x (T_h,in - T_h,out)"    << nl
         << "    Source  : T_h,out from hot_outlet patch"                 << nl
         << "    Value   = " << Q_hot << " W"                             << nl << nl;

    Info << "  Q_cold [W]"                                                 << nl
         << "    Formula : Q_cold = m_strip x Cp x (T_c,out - T_c,in)"   << nl
         << "    Source  : T_c,out from cold_outlet patch"                << nl
         << "    Value   = " << Q_cold << " W"                            << nl << nl;

    scalar V    = W * tp2 * channelLength;   // volume from mesh values
    scalar Qvol = Q_hot / V / 1.0e6;

    Info << "  Q_vol [MW/m3]"                                              << nl
         << "    Formula : Q_vol = Q_hot / (W x 2tp x L) / 1e6"          << nl
         << "    Volume  = " << V << " m3"                                << nl
         << "    Value   = " << Qvol << " MW/m3"                          << nl << nl;

    scalar dT1  = T_h_in    - T_cold_out;
    scalar dT2  = T_hot_out - T_c_in;
    scalar LMTD = 0.0;
    if (dT1 > SMALL && dT2 > SMALL && mag(dT1-dT2) > SMALL)
        LMTD = (dT1 - dT2) / Foam::log(dT1 / dT2);

    Info << "  LMTD [K]  (counter-flow)"                                  << nl
         << "    Formula : (dT1-dT2) / ln(dT1/dT2)"                      << nl
         << "    dT1 = T_h,in  - T_c,out = " << dT1 << " K"              << nl
         << "    dT2 = T_h,out - T_c,in  = " << dT2 << " K"              << nl
         << "    Value   = " << LMTD << " K"                              << nl << nl;

    // ── MESH AREAS ────────────────────────────────────────────────────────────
    Info << "-----------------------------------------------------" << nl
         << "  MESH AREAS -- READ DIRECTLY FROM PATCHES"            << nl
         << "-----------------------------------------------------" << nl << endl;

    auto readPatchArea = [&](const fvMesh& mesh, const word& pName) -> scalar
    {
        label pID = mesh.boundaryMesh().findPatchID(pName);
        if (pID >= 0)
        {
            scalar area = gSum(mesh.boundary()[pID].magSf());
            Info << "  Patch : " << pName
                 << "    Region : " << mesh.name()
                 << "    Faces : " << mesh.boundary()[pID].size()
                 << "    Area : " << area << " m2" << nl;
            return area;
        }
        Info << "  Patch : " << pName << " -- NOT FOUND in " << mesh.name() << nl;
        return 0.0;
    };

    Info << "  --- CHT Interface Patches ---" << nl << endl;
    scalar A_hot_to_solid  = readPatchArea(meshHot,   "hot_fluid_to_solid_plate");
    scalar A_cold_to_solid = readPatchArea(meshCold,  "cold_fluid_to_solid_plate");
    scalar A_solid_to_hot  = readPatchArea(meshSolid, "solid_plate_to_hot_fluid");
    scalar A_solid_to_cold = readPatchArea(meshSolid, "solid_plate_to_cold_fluid");

    Info << nl
         << "  --- CHT Interface Area Verification ---"                   << nl
         << "  hot_fluid_to_solid_plate   = " << A_hot_to_solid  << " m2" << nl
         << "  cold_fluid_to_solid_plate  = " << A_cold_to_solid << " m2" << nl
         << "  solid_plate_to_hot_fluid   = " << A_solid_to_hot  << " m2" << nl
         << "  solid_plate_to_cold_fluid  = " << A_solid_to_cold << " m2" << nl
         << "  All patches should be equal (same physical interface)"     << nl
         << endl;

    scalar As       = 0.0;
    word   AsSource = "";
    if      (A_hot_to_solid  > SMALL) { As = A_hot_to_solid;  AsSource = "hot_fluid_to_solid_plate";  }
    else if (A_cold_to_solid > SMALL) { As = A_cold_to_solid; AsSource = "cold_fluid_to_solid_plate"; }
    else if (A_solid_to_hot  > SMALL) { As = A_solid_to_hot;  AsSource = "solid_plate_to_hot_fluid";  }
    else if (A_solid_to_cold > SMALL) { As = A_solid_to_cold; AsSource = "solid_plate_to_cold_fluid"; }

    Info << "  As used for U calculation:"                               << nl
         << "    Source : " << AsSource                                   << nl
         << "    As     = " << As << " m2"                               << nl << nl;

    Info << "  --- Inlet Cross-Section Areas ---" << nl << endl;
    scalar A_hot_inlet  = readPatchArea(meshHot,  "hot_inlet");
    scalar A_cold_inlet = readPatchArea(meshCold, "cold_inlet");
    Info << nl
         << "  Cross-section areas:"                                      << nl
         << "    Hot  channel = " << A_hot_inlet  << " m2"               << nl
         << "    Cold channel = " << A_cold_inlet << " m2"               << nl
         << endl;

    scalar U = 0.0;
    if (mag(As * LMTD) > SMALL)
        U = Q_hot / (As * LMTD);

    Info << "  U [W/m2K]"                                                 << nl
         << "    Formula : U = Q_hot / (As x LMTD)"                      << nl
         << "    Source  : As from " << AsSource                          << nl
         << "    Value   = " << U << " W/m2K"                            << nl << endl;

    // ── ADDITIONAL PERFORMANCE PARAMETERS ────────────────────────────────────
    Info << "-----------------------------------------------------" << nl
         << "  ADDITIONAL PERFORMANCE PARAMETERS"                    << nl
         << "-----------------------------------------------------" << nl << endl;

    // Hydraulic diameter -- read from mesh cross-section area
    // Dh = 4 x A_c / P_w
    // For semicircular channel: A_c = pi x d^2 / 8,  P_w = pi x d / 2
    // So Dh = 4 x (pi x d^2/8) / (pi x d/2) = d
    // Read A_c from mesh directly
    scalar A_c  = A_hot_inlet;    // cross-section area from mesh [m2]
    scalar P_w  = As / channelLength;  // wetted perimeter = As / L
    scalar Dh   = 0.0;
    if (P_w > SMALL)
        Dh = 4.0 * A_c / P_w;

    Info << "  Dh [m]  (hydraulic diameter)"                             << nl
         << "    Formula : Dh = 4 x A_c / P_w"                          << nl
         << "    A_c     = " << A_c  << " m2  (from hot_inlet patch)"   << nl
         << "    P_w     = " << P_w  << " m   (As / channelLength)"     << nl
         << "    Value   = " << Dh   << " m"                             << nl
         << "            = " << Dh*1000 << " mm"                         << nl << nl;

    // Inlet velocity -- from mass flow rate and cross-section area
    // u = m_strip / (rho x A_c)
    // Read rho from thermophysicalProperties
    // Read rho -- try equationOfState subdict first then mixture directly
    scalar rho_fluid = 1.455;   // default fallback
    const dictionary& mixDict = hotThermoDict.subDict("mixture");

    if (mixDict.found("equationOfState"))
    {
        rho_fluid = mixDict.subDict("equationOfState")
                           .get<scalar>("rho");
        Info << "    rho read from mixture/equationOfState/rho" << nl;
    }
    else if (mixDict.found("rho"))
    {
        rho_fluid = mixDict.get<scalar>("rho");
        Info << "    rho read from mixture/rho directly" << nl;
    }
    else
    {
        // Compute from ideal gas: rho = P / (R/M x T)
        // At 3MPa, 993K: rho = 3e6 / (8314/4.0026 x 993) = 1.455 kg/m3
        Info << "    rho not found -- using default 1.455 kg/m3 (He @ 993K 3MPa)" << nl;
    }
    scalar u_inlet = 0.0;
    if (rho_fluid * A_c > SMALL)
        u_inlet = m_strip / (rho_fluid * A_c);

    Info << "  u_inlet [m/s]  (mean inlet velocity)"                     << nl
         << "    Formula : u = m_strip / (rho x A_c)"                   << nl
         << "    rho     = " << rho_fluid << " kg/m3  (from thermophysicalProperties)" << nl
         << "    Value   = " << u_inlet << " m/s"                        << nl << nl;

    // ── REYNOLDS NUMBER Re ────────────────────────────────────────────────────
    // Re = rho x u x Dh / mu
    // Source: rho from thermophysicalProperties
    //         u from m_strip / (rho x A_c)
    //         Dh from mesh geometry
    //         mu from thermophysicalProperties
    scalar Re = 0.0;
    if (mu_fluid > SMALL)
        Re = rho_fluid * u_inlet * Dh / mu_fluid;

    Info << "  Re -- Reynolds number"                                     << nl
         << "    Formula : Re = rho x u x Dh / mu"                      << nl
         << "    rho     = " << rho_fluid << " kg/m3"                    << nl
         << "    u       = " << u_inlet   << " m/s"                      << nl
         << "    Dh      = " << Dh        << " m"                        << nl
         << "    mu      = " << mu_fluid  << " Pa.s"                     << nl
         << "    Value   = " << Re << " [-]"                              << nl << nl;

    // ── PRANDTL NUMBER Pr ─────────────────────────────────────────────────────
    // Already read from thermophysicalProperties -- just print
    scalar Pr = Pr_fluid;
    Info << "  Pr -- Prandtl number"                                      << nl
         << "    Formula : Pr = mu x Cp / kf"                            << nl
         << "    Source  : read from thermophysicalProperties"            << nl
         << "    Value   = " << Pr << " [-]"                              << nl << nl;

    // ── FRICTION FACTOR f ─────────────────────────────────────────────────────
    // f = dP x Dh / (0.5 x rho x u^2 x L)
    // Source: dP from p_rgh patches, Dh from mesh, rho and u from fields
    scalar f_hot  = 0.0;
    scalar f_cold = 0.0;
    if (0.5 * rho_fluid * u_inlet * u_inlet * channelLength > SMALL)
    {
        f_hot  = dP_hot  * Dh / (0.5 * rho_fluid * u_inlet * u_inlet * channelLength);
        f_cold = dP_cold * Dh / (0.5 * rho_fluid * u_inlet * u_inlet * channelLength);
    }

    Info << "  f -- Friction factor"                                      << nl
         << "    Formula : f = dP x Dh / (0.5 x rho x u^2 x L)"        << nl
         << "    Source  : dP from p_rgh patches"                        << nl
         << "              Dh from mesh geometry"                         << nl
         << "              rho from thermophysicalProperties"             << nl
         << "              u from m_strip / (rho x A_c)"                 << nl
         << "    f_hot   = " << f_hot  << " [-]"                         << nl
         << "    f_cold  = " << f_cold << " [-]"                         << nl << nl;

    // ── NUSSELT NUMBER Nu ─────────────────────────────────────────────────────
    // Nu = U x Dh / kf
    // Source: U from LMTD method, Dh from mesh, kf from thermophysicalProperties
    scalar Nu = 0.0;
    if (kappa_fluid > SMALL && Dh > SMALL)
        Nu = U * Dh / kappa_fluid;

    Info << "  Nu -- Nusselt number"                                      << nl
         << "    Formula : Nu = U x Dh / kf"                             << nl
         << "    Source  : U from LMTD method"                           << nl
         << "              Dh from mesh geometry"                         << nl
         << "              kf = kappa_fluid from thermophysicalProperties" << nl
         << "    U       = " << U          << " W/m2K"                   << nl
         << "    Dh      = " << Dh         << " m"                       << nl
         << "    kf      = " << kappa_fluid << " W/mK"                   << nl
         << "    Value   = " << Nu << " [-]"                              << nl << nl;

    // ── GRAETZ NUMBER Gz ──────────────────────────────────────────────────────
    // Gz = Re x Pr x Dh / L
    // Gz > 100 : thermally developing -- entry effects dominant
    // Gz 10-100: transition region
    // Gz < 10  : thermally fully developed
    scalar Gz = 0.0;
    if (channelLength > SMALL)
        Gz = Re * Pr * Dh / channelLength;

    Info << "  Gz -- Graetz number  (thermal entry length)"               << nl
         << "    Formula : Gz = Re x Pr x Dh / L"                       << nl
         << "    Value   = " << Gz << " [-]"                              << nl
         << "    Gz > 100 : thermally developing -- entry effects"       << nl
         << "    Gz 10-100: transition region"                            << nl
         << "    Gz < 10  : thermally fully developed"                    << nl
         << "    Status   : ";
    if (Gz > 100)
        Info << "THERMALLY DEVELOPING -- entry effects significant"       << nl << nl;
    else if (Gz > 10)
        Info << "TRANSITION region"                                        << nl << nl;
    else
        Info << "THERMALLY FULLY DEVELOPED"                               << nl << nl;

    // ── COLBURN FACTOR j ──────────────────────────────────────────────────────
    // j = Nu / (Re x Pr^(1/3))
    // Higher j = better heat transfer at same Re
    scalar j_factor = 0.0;
    if (Re * Foam::pow(Pr, 1.0/3.0) > SMALL)
        j_factor = Nu / (Re * Foam::pow(Pr, 1.0/3.0));

    Info << "  j -- Colburn factor  (heat transfer analogy)"              << nl
         << "    Formula : j = Nu / (Re x Pr^(1/3))"                    << nl
         << "    Value   = " << j_factor << " [-]"                       << nl
         << "    Higher j = better heat transfer at same Re"             << nl << nl;

    // ── POISEUILLE NUMBER Po ──────────────────────────────────────────────────
    // Po = f x Re -- shape factor for duct geometry
    // Circular: 64  Semicircle: 52.9  Square: 56.9  Parallel plates: 96
    scalar Po = f_hot * Re;

    Info << "  Po -- Poiseuille number  (duct shape factor)"              << nl
         << "    Formula : Po = f x Re"                                  << nl
         << "    Value   = " << Po << " [-]"                              << nl
         << "    Reference values:"                                        << nl
         << "      Circular duct   : Po = 64.0"                          << nl
         << "      Semicircle duct : Po = 52.9 (theoretical)"            << nl
         << "      Square duct     : Po = 56.9"                          << nl
         << "      Parallel plates : Po = 96.0"                          << nl << nl;

    // ── EULER NUMBER Eu ───────────────────────────────────────────────────────
    // Eu = dP / (0.5 x rho x u^2) -- useful for short channels
    scalar Eu_hot  = 0.0;
    scalar Eu_cold = 0.0;
    if (0.5 * rho_fluid * u_inlet * u_inlet > SMALL)
    {
        Eu_hot  = dP_hot  / (0.5 * rho_fluid * u_inlet * u_inlet);
        Eu_cold = dP_cold / (0.5 * rho_fluid * u_inlet * u_inlet);
    }

    Info << "  Eu -- Euler number  (pressure loss coefficient)"           << nl
         << "    Formula : Eu = dP / (0.5 x rho x u^2)"                 << nl
         << "    Eu_hot  = " << Eu_hot  << " [-]"                        << nl
         << "    Eu_cold = " << Eu_cold << " [-]"                        << nl
         << "    Useful for short channels"                               << nl << nl;

    // ── PUMPING POWER PP ──────────────────────────────────────────────────────
    // PP = dP x V_dot  where V_dot = m_strip / rho  [m3/s]
    // Source: dP from p_rgh patches, m_strip from phi, rho from thermophysicalProperties
    scalar V_dot = 0.0;
    if (rho_fluid > SMALL)
        V_dot = m_strip / rho_fluid;

    scalar PP_hot  = dP_hot  * V_dot;
    scalar PP_cold = dP_cold * V_dot;

    Info << "  PP [W]  -- Pumping power"                                  << nl
         << "    Formula : PP = dP x V_dot  where V_dot = m_strip / rho" << nl
         << "    Source  : dP from p_rgh patches"                        << nl
         << "              m_strip from phi field"                        << nl
         << "              rho from thermophysicalProperties"             << nl
         << "    V_dot   = " << V_dot   << " m3/s"                       << nl
         << "    PP_hot  = " << PP_hot  << " W"                           << nl
         << "    PP_cold = " << PP_cold << " W"                           << nl << nl;

    // ── THERMAL RESISTANCE Rth ────────────────────────────────────────────────
    // Rth = 1 / (U x As)  [K/W]
    // Lower Rth = Better heat transfer performance
    // Source: U from LMTD method, As from CHT interface patch
    scalar Rth = 0.0;
    if (U * As > SMALL)
        Rth = 1.0 / (U * As);

    Info << "  Rth [K/W]  -- Thermal resistance"                          << nl
         << "    Formula : Rth = 1 / (U x As)"                           << nl
         << "    Source  : U from LMTD method"                           << nl
         << "              As from " << AsSource << " patch"              << nl
         << "    U       = " << U   << " W/m2K"                          << nl
         << "    As      = " << As  << " m2"                              << nl
         << "    Value   = " << Rth << " K/W"                             << nl << nl;

    // ── ENERGY BALANCE 1 ─────────────────────────────────────────────────────
    scalar balance_err = 0.0;
    if (mag(Q_hot) > SMALL)
        balance_err = mag(Q_hot - Q_cold) / mag(Q_hot) * 100.0;

    Info << "-----------------------------------------------------" << nl
         << "  ENERGY BALANCE 1 -- GLOBAL (from outlet T)"          << nl
         << "-----------------------------------------------------" << nl
         << "  Formula : |Q_hot - Q_cold| / Q_hot x 100"           << nl
         << "  Q_hot   = " << Q_hot   << " W"                       << nl
         << "  Q_cold  = " << Q_cold  << " W"                       << nl
         << "  Balance = " << balance_err << " %"                   << nl << endl;

    // ── ENERGY BALANCE 2 -- CHT INTERFACE HEAT FLUX ──────────────────────────
    Info << "-----------------------------------------------------" << nl
         << "  ENERGY BALANCE 2 -- CHT INTERFACE HEAT FLUX"         << nl
         << "  Method: Q = kappa x snGrad(T) x patch area"         << nl
         << "-----------------------------------------------------" << nl << endl;

    scalar Q_hot_to_solid  = 0.0;
    scalar Q_cold_to_solid = 0.0;
    scalar Q_solid_to_hot  = 0.0;
    scalar Q_solid_to_cold = 0.0;

    // [1] hot_fluid_to_solid_plate
    if (hotToSolidID >= 0)
    {
        const fvPatch& patch  = meshHot.boundary()[hotToSolidID];
        scalarField snGradT   = T_hot.boundaryField()[hotToSolidID].snGrad();
        const scalarField& Sf = patch.magSf();
        Q_hot_to_solid        = kappa_fluid * gSum(snGradT * Sf);
        Info << "  [1] hot_fluid_to_solid_plate"                         << nl
             << "      Region  : hot_fluid"                              << nl
             << "      Faces   : " << patch.size()                       << nl
             << "      Area    : " << gSum(Sf) << " m2"                  << nl
             << "      kappa   : " << kappa_fluid << " W/mK (He)"        << nl
             << "      Q       = " << Q_hot_to_solid << " W"             << nl << nl;
    }
    else
        Info << "  [1] hot_fluid_to_solid_plate -- NOT FOUND" << nl << nl;

    // [2] cold_fluid_to_solid_plate
    if (coldToSolidID >= 0)
    {
        const fvPatch& patch  = meshCold.boundary()[coldToSolidID];
        scalarField snGradT   = T_cold.boundaryField()[coldToSolidID].snGrad();
        const scalarField& Sf = patch.magSf();
        Q_cold_to_solid       = kappa_fluid * gSum(snGradT * Sf);
        Info << "  [2] cold_fluid_to_solid_plate"                        << nl
             << "      Region  : cold_fluid"                             << nl
             << "      Faces   : " << patch.size()                       << nl
             << "      Area    : " << gSum(Sf) << " m2"                  << nl
             << "      kappa   : " << kappa_fluid << " W/mK (He)"        << nl
             << "      Q       = " << Q_cold_to_solid << " W"            << nl << nl;
    }
    else
        Info << "  [2] cold_fluid_to_solid_plate -- NOT FOUND" << nl << nl;

    // [3] solid_plate_to_hot_fluid
    if (solidToHotID >= 0)
    {
        const fvPatch& patch  = meshSolid.boundary()[solidToHotID];
        scalarField snGradT   = T_solid.boundaryField()[solidToHotID].snGrad();
        const scalarField& Sf = patch.magSf();
        Q_solid_to_hot        = kappa_solid * gSum(snGradT * Sf);
        Info << "  [3] solid_plate_to_hot_fluid"                         << nl
             << "      Region  : solid_plate"                            << nl
             << "      Faces   : " << patch.size()                       << nl
             << "      Area    : " << gSum(Sf) << " m2"                  << nl
             << "      kappa   : " << kappa_solid << " W/mK (Alloy-617)" << nl
             << "      Q       = " << Q_solid_to_hot << " W"             << nl << nl;
    }
    else
        Info << "  [3] solid_plate_to_hot_fluid -- NOT FOUND" << nl << nl;

    // [4] solid_plate_to_cold_fluid
    if (solidToColdID >= 0)
    {
        const fvPatch& patch  = meshSolid.boundary()[solidToColdID];
        scalarField snGradT   = T_solid.boundaryField()[solidToColdID].snGrad();
        const scalarField& Sf = patch.magSf();
        Q_solid_to_cold       = kappa_solid * gSum(snGradT * Sf);
        Info << "  [4] solid_plate_to_cold_fluid"                        << nl
             << "      Region  : solid_plate"                            << nl
             << "      Faces   : " << patch.size()                       << nl
             << "      Area    : " << gSum(Sf) << " m2"                  << nl
             << "      kappa   : " << kappa_solid << " W/mK (Alloy-617)" << nl
             << "      Q       = " << Q_solid_to_cold << " W"            << nl << nl;
    }
    else
        Info << "  [4] solid_plate_to_cold_fluid -- NOT FOUND" << nl << nl;

    scalar interface_balance = 0.0;
    if (mag(Q_hot_to_solid) > SMALL)
        interface_balance =
            mag(mag(Q_hot_to_solid) - mag(Q_cold_to_solid))
            / mag(Q_hot_to_solid) * 100.0;

    Info << "  --- Interface Balance Summary ---"                          << nl
         << "  hot_fluid_to_solid_plate  Q = " << Q_hot_to_solid  << " W" << nl
         << "  cold_fluid_to_solid_plate Q = " << Q_cold_to_solid << " W" << nl
         << "  solid_plate_to_hot_fluid  Q = " << Q_solid_to_hot  << " W" << nl
         << "  solid_plate_to_cold_fluid Q = " << Q_solid_to_cold << " W" << nl
         << "  Balance 2 = " << interface_balance << " %"                 << nl << endl;

    // ── ENERGY BALANCE 3 ─────────────────────────────────────────────────────
    scalar Q_bal3_hot  = mag(Q_hot_to_solid);
    scalar Q_bal3_cold = mag(Q_cold_to_solid);
    scalar balance3    = 0.0;
    if (Q_bal3_hot > SMALL)
        balance3 = mag(Q_bal3_hot - Q_bal3_cold) / Q_bal3_hot * 100.0;

    Info << "-----------------------------------------------------" << nl
         << "  ENERGY BALANCE 3 -- DIRECT WALL FLUX COMPARISON"     << nl
         << "-----------------------------------------------------" << nl
         << "  Q_hot  = mag(hot_fluid_to_solid_plate)  = " << Q_bal3_hot  << " W" << nl
         << "  Q_cold = mag(cold_fluid_to_solid_plate) = " << Q_bal3_cold << " W" << nl
         << "  Formula : |Q_hot - Q_cold| / Q_hot x 100"            << nl
         << "  Balance = " << balance3 << " %"                       << nl
         << "  If < 1% --> solid plate at steady state"              << nl
         << "  If > 1% --> solid still accumulating energy"          << nl << endl;

    // ── BALANCE 4 -- MASS CONSERVATION ───────────────────────────────────────
    Info << "-----------------------------------------------------" << nl
         << "  BALANCE 4 -- MASS CONSERVATION"                       << nl
         << "  Method: integrate phi at inlet and outlet patches"    << nl
         << "-----------------------------------------------------" << nl << endl;

    scalar phi_hot_inlet  = phi_hot_inlet_sum;   // already read above
    scalar phi_hot_outlet = gSum(phi_hot.boundaryField()[hotOutletID]);
    scalar m_hot_in       = mag(phi_hot_inlet);
    scalar m_hot_out      = mag(phi_hot_outlet);
    scalar mass_bal_hot   = 0.0;
    if (m_hot_in > SMALL)
        mass_bal_hot = mag(m_hot_in - m_hot_out) / m_hot_in * 100.0;

    Info << "  HOT FLUID mass conservation:"                             << nl
         << "    phi at hot_inlet   = " << phi_hot_inlet  << " kg/s"    << nl
         << "    phi at hot_outlet  = " << phi_hot_outlet << " kg/s"    << nl
         << "    m_dot_in           = " << m_hot_in  << " kg/s"         << nl
         << "    m_dot_out          = " << m_hot_out << " kg/s"         << nl
         << "    Set mass flow rate = " << m_strip   << " kg/s"         << nl
         << "    Balance            = " << mass_bal_hot << " %"         << nl << nl;

    scalar phi_cold_inlet  = gSum(phi_cold.boundaryField()[coldInletID]);
    scalar phi_cold_outlet = gSum(phi_cold.boundaryField()[coldOutletID]);
    scalar m_cold_in       = mag(phi_cold_inlet);
    scalar m_cold_out      = mag(phi_cold_outlet);
    scalar mass_bal_cold   = 0.0;
    if (m_cold_in > SMALL)
        mass_bal_cold = mag(m_cold_in - m_cold_out) / m_cold_in * 100.0;

    Info << "  COLD FLUID mass conservation:"                            << nl
         << "    phi at cold_inlet  = " << phi_cold_inlet  << " kg/s"   << nl
         << "    phi at cold_outlet = " << phi_cold_outlet << " kg/s"   << nl
         << "    m_dot_in           = " << m_cold_in  << " kg/s"        << nl
         << "    m_dot_out          = " << m_cold_out << " kg/s"        << nl
         << "    Set mass flow rate = " << m_strip    << " kg/s"        << nl
         << "    Balance            = " << mass_bal_cold << " %"        << nl << nl;

    scalar hot_mdot_error  = mag(m_hot_in  - m_strip) / m_strip * 100.0;
    scalar cold_mdot_error = mag(m_cold_in - m_strip) / m_strip * 100.0;

    Info << "  Mass flow rate vs set value:"                             << nl
         << "    Hot  : actual=" << m_hot_in  << " set=" << m_strip
         << " error=" << hot_mdot_error  << " %"                        << nl
         << "    Cold : actual=" << m_cold_in << " set=" << m_strip
         << " error=" << cold_mdot_error << " %"                        << nl << endl;

    // ── AUTOMATIC DIAGNOSIS ───────────────────────────────────────────────────
    bool b1ok   = (balance_err       < 1.0);
    bool b2ok   = (interface_balance < 1.0);
    bool b3ok   = (balance3          < 1.0);
    bool b4ok   = (mass_bal_hot < 0.1 && mass_bal_cold < 0.1);
    bool b2warn = (interface_balance > 5.0);
    bool b3warn = (balance3          > 5.0);

    Info << "=====================================================" << nl
         << "  CONVERGENCE DIAGNOSIS"                                << nl
         << "=====================================================" << nl
         << nl
         << "  Balance 1 = " << balance_err       << " %  (global -- outlet T)"     << nl
         << "  Balance 2 = " << interface_balance << " %  (CHT interface flux)"     << nl
         << "  Balance 3 = " << balance3          << " %  (solid steady state)"     << nl
         << "  Balance 4 = " << mass_bal_hot      << " %  (hot mass conservation)"  << nl
         << "             = " << mass_bal_cold    << " %  (cold mass conservation)" << nl
         << nl
         << "  Status:"                                              << nl
         << "    Balance 1 : ";
    if (b1ok)
        Info << "[OK]      < 1%    -- global energy conserved"      << nl;
    else
        Info << "[FAIL]    > 1%    -- global energy not conserved"  << nl;

    Info << "    Balance 2 : ";
    if (b2ok)
        Info << "[OK]      < 1%    -- CHT coupling correct"         << nl;
    else if (b2warn)
        Info << "[FAIL]    > 5%    -- CHT interface problem"        << nl;
    else
        Info << "[WARNING] 1-5%    -- CHT coupling marginal"        << nl;

    Info << "    Balance 3 : ";
    if (b3ok)
        Info << "[OK]      < 1%    -- solid at steady state"        << nl;
    else if (b3warn)
        Info << "[FAIL]    > 5%    -- solid far from steady state"  << nl;
    else
        Info << "[WARNING] 1-5%    -- solid nearly converged"       << nl;

    Info << "    Balance 4 : ";
    if (b4ok)
        Info << "[OK]      < 0.1%  -- mass conserved both regions"  << nl;
    else if (mass_bal_hot < 1.0 && mass_bal_cold < 1.0)
        Info << "[WARNING] < 1%    -- mass nearly conserved"        << nl;
    else
        Info << "[FAIL]    > 1%    -- mass not conserved"           << nl;

    Info << nl << "  Diagnosis : ";

    if (b1ok && b2ok && b3ok && b4ok)
        Info << "FULLY CONVERGED -- all four balances OK"           << nl
             << "    Ready to extract results and post-process"      << nl;
    else if (!b1ok && !b2ok && !b3ok)
        Info << "NOT CONVERGED -- run more iterations"              << nl;
    else if (b1ok && b2warn && b3warn)
        Info << "CHT COUPLING ISSUE -- check mapped wall BC"        << nl;
    else if (b1ok && b2ok && !b3ok)
        Info << "SOLID NOT AT STEADY STATE -- run more iterations"  << nl;
    else if (b1ok && !b2ok && !b3ok)
        Info << "POOR CHT COUPLING -- reduce relaxation factors"    << nl;
    else if (!b4ok)
        Info << "MASS NOT CONSERVED -- check phi and p_rgh relax"   << nl;
    else if (!b1ok && b2ok && b3ok)
        Info << "FLUID NOT CONVERGED -- run more iterations"        << nl;
    else
        Info << "PARTIALLY CONVERGED -- run more and recheck"       << nl;

    Info << nl
         << "  Quick reference:"                                          << nl
         << "  Bal1  Bal2  Bal3  Bal4    Diagnosis"                      << nl
         << "  <1%   <1%   <1%   <0.1%   Fully converged -- OK"          << nl
         << "  >1%   >1%   >1%   any     Not converged -- run more"      << nl
         << "  <1%   >5%   >5%   OK      CHT issue -- check BC"          << nl
         << "  <1%   <1%   >1%   OK      Solid not steady -- run more"   << nl
         << "  <1%   >1%   >1%   OK      Poor coupling -- reduce relax"  << nl
         << "  any   any   any   >1%     Mass not conserved -- check phi" << nl
         << "=====================================================" << nl << endl;

    // ── SUMMARY ──────────────────────────────────────────────────────────────
    Info << "=====================================================" << nl
         << "  SIMULATION RESULTS SUMMARY"                          << nl
         << "=====================================================" << nl
         << nl
         << "  channelLength      " << channelLength      << "   m"      << nl
         << "  dP_hot             " << dP_hot/1000.0      << "   kPa"    << nl
         << "  dP/L hot           " << dPdL_hot/1000.0    << "   kPa/m"  << nl
         << "  dP_cold            " << dP_cold/1000.0     << "   kPa"    << nl
         << "  dP/L cold          " << dPdL_cold/1000.0   << "   kPa/m"  << nl
         << "  T_h,out            " << T_hot_out           << "   K"      << nl
         << "  T_c,out            " << T_cold_out          << "   K"      << nl
         << "  Q_hot              " << Q_hot               << "   W"      << nl
         << "  Q_cold             " << Q_cold              << "   W"      << nl
         << "  Q_vol              " << Qvol                << "   MW/m3"  << nl
         << "  LMTD               " << LMTD                << "   K"      << nl
         << "  As                 " << As                  << "   m2"     << nl
         << "  U                  " << U                   << "   W/m2K"  << nl
         << "  Dh                 " << Dh*1000             << "   mm"     << nl
         << "  u_inlet            " << u_inlet             << "   m/s"    << nl
         << "  Re                 " << Re                  << "   [-]"    << nl
         << "  Pr                 " << Pr                  << "   [-]"    << nl
         << "  Gz                 " << Gz                  << "   [-]"    << nl
         << "  f_hot              " << f_hot               << "   [-]"    << nl
         << "  f_cold             " << f_cold              << "   [-]"    << nl
         << "  Nu                 " << Nu                  << "   [-]"    << nl
         << "  j (Colburn)        " << j_factor            << "   [-]"    << nl
         << "  Po                 " << Po                  << "   [-]"    << nl
         << "  Eu_hot             " << Eu_hot              << "   [-]"    << nl
         << "  Eu_cold            " << Eu_cold             << "   [-]"    << nl
         << "  PP_hot             " << PP_hot              << "   W"      << nl
         << "  PP_cold            " << PP_cold             << "   W"      << nl
         << "  Rth                " << Rth                 << "   K/W"    << nl
         << "  Energy bal.1       " << balance_err         << "   %"      << nl
         << "  Q_hot->solid       " << Q_hot_to_solid      << "   W"      << nl
         << "  Q_cold->solid      " << Q_cold_to_solid     << "   W"      << nl
         << "  Q_solid->hot       " << Q_solid_to_hot      << "   W"      << nl
         << "  Q_solid->cold      " << Q_solid_to_cold     << "   W"      << nl
         << "  Interface bal.2    " << interface_balance    << "   %"      << nl
         << "  Balance 3          " << balance3             << "   %"      << nl
         << "  m_dot_hot          " << m_hot_in             << "   kg/s"   << nl
         << "  m_dot_cold         " << m_cold_in            << "   kg/s"   << nl
         << "  Mass bal. hot      " << mass_bal_hot         << "   %"      << nl
         << "  Mass bal. cold     " << mass_bal_cold        << "   %"      << nl
         << "=====================================================" << nl << endl;

    // ── WRITE TO FILE ─────────────────────────────────────────────────────────
    mkDir(runTime.globalPath()/"postProcessing");
    OFstream resultsFile
    (
        runTime.globalPath()/"postProcessing"/"pressureDrop_results.txt"
    );

    resultsFile
        << "PCHE Strip Channel Post-Processing Results"          << nl
        << "PCHE strip channel simulation"         << nl
        << "Time = " << runTime.timeName()                       << nl
        << nl
        << "=== GEOMETRY ==="                                    << nl
        << "channelLength [m]     = " << channelLength           << nl
        << "channelLength [mm]    = " << channelLength*1000      << nl
        << "W             [mm]    = " << W*1000
        << "  (HARDCODED -- pressureDrop.C line 58 -- strip channel geometry Table 1)" << nl        << "tp2           [mm]    = " << tp2*1000
        << "  (HARDCODED -- pressureDrop.C line 59 -- strip channel geometry Table 1)" << nl
        << nl
        << "=== HOT FLUID ==="                                   << nl
        << "P_hot_inlet   [Pa]    = " << P_hot_in                << nl
        << "P_hot_outlet  [Pa]    = " << P_hot_out               << nl
        << "dP_hot        [Pa]    = " << dP_hot                  << nl
        << "dP_hot        [kPa]   = " << dP_hot/1000             << nl
        << "dPdL_hot      [Pa/m]  = " << dPdL_hot                << nl
        << "dPdL_hot      [kPa/m] = " << dPdL_hot/1000           << nl
        << "T_hot_outlet  [K]     = " << T_hot_out               << nl
        << nl
        << "=== COLD FLUID ==="                                  << nl
        << "P_cold_inlet  [Pa]    = " << P_cold_in               << nl
        << "P_cold_outlet [Pa]    = " << P_cold_out              << nl
        << "dP_cold       [Pa]    = " << dP_cold                 << nl
        << "dP_cold       [kPa]   = " << dP_cold/1000            << nl
        << "dPdL_cold     [Pa/m]  = " << dPdL_cold               << nl
        << "dPdL_cold     [kPa/m] = " << dPdL_cold/1000          << nl
        << "T_cold_outlet [K]     = " << T_cold_out              << nl
        << nl
        << "=== DERIVED ==="                                     << nl
        << "Q_hot         [W]     = " << Q_hot                   << nl
        << "Q_cold        [W]     = " << Q_cold                  << nl
        << "Q_vol         [MW/m3] = " << Qvol                    << nl
        << "LMTD          [K]     = " << LMTD                    << nl
        << "As            [m2]    = " << As                      << nl
        << "U             [W/m2K] = " << U                       << nl
        << nl
        << "=== PERFORMANCE PARAMETERS ==="                      << nl
        << "Dh            [mm]    = " << Dh*1000                 << nl
        << "u_inlet       [m/s]   = " << u_inlet                 << nl
        << "Re            [-]     = " << Re                      << nl
        << "Pr            [-]     = " << Pr                      << nl
        << "Gz            [-]     = " << Gz                      << nl
        << "f_hot         [-]     = " << f_hot                   << nl
        << "f_cold        [-]     = " << f_cold                  << nl
        << "Nu            [-]     = " << Nu                      << nl
        << "j_Colburn     [-]     = " << j_factor                << nl
        << "Po            [-]     = " << Po                      << nl
        << "Eu_hot        [-]     = " << Eu_hot                  << nl
        << "Eu_cold       [-]     = " << Eu_cold                 << nl
        << "PP_hot        [W]     = " << PP_hot                  << nl
        << "PP_cold       [W]     = " << PP_cold                 << nl
        << "Rth           [K/W]   = " << Rth                     << nl
        << nl
        << "=== ENERGY BALANCES ==="                             << nl
        << "Balance_1     [%]     = " << balance_err             << nl
        << "Q_hot->solid  [W]     = " << Q_hot_to_solid          << nl
        << "Q_cold->solid [W]     = " << Q_cold_to_solid         << nl
        << "Q_solid->hot  [W]     = " << Q_solid_to_hot          << nl
        << "Q_solid->cold [W]     = " << Q_solid_to_cold         << nl
        << "Balance_2     [%]     = " << interface_balance        << nl
        << "Q_bal3_hot    [W]     = " << Q_bal3_hot               << nl
        << "Q_bal3_cold   [W]     = " << Q_bal3_cold              << nl
        << "Balance_3     [%]     = " << balance3                 << nl
        << nl
        << "=== MASS CONSERVATION ==="                           << nl
        << "m_dot_hot     [kg/s]  = " << m_hot_in                << nl
        << "m_dot_cold    [kg/s]  = " << m_cold_in               << nl
        << "m_dot_set     [kg/s]  = " << m_strip                 << nl
        << "Mass_bal_hot  [%]     = " << mass_bal_hot             << nl
        << "Mass_bal_cold [%]     = " << mass_bal_cold            << nl
        << nl
        << "=== DIAGNOSIS ==="                                   << nl
        << "Balance1      = " << (b1ok ? "OK" : "FAIL")          << nl
        << "Balance2      = " << (b2ok ? "OK" : (b2warn ? "FAIL" : "WARNING")) << nl
        << "Balance3      = " << (b3ok ? "OK" : (b3warn ? "FAIL" : "WARNING")) << nl
        << "Balance4      = " << (b4ok ? "OK" : "FAIL")          << nl;

    Info << "Results saved to: postProcessing/pressureDrop_results.txt"
         << nl << endl;

    return 0;
}

// ************************************************************************* //